from django.apps import AppConfig


class LanguagetestsConfig(AppConfig):
    name = 'languageTests'
