from django import template
from django import forms
from django.utils.safestring import mark_safe
register = template.Library()
import re



#from ..models import Answer
@register.simple_tag
def add_choices_to_excersise(excersise_text,form,answers):
    #print("range=<{}>",format(len(answers)))
    it=iter(answers)
    output_string=excersise_text
    error_html=""
    error_html_text=""
    error_in_answers=False
    counter=1
    for ans in it:
        ans=next(it)
        #print("aaa{}aaa".format(form.fields[ans].get_bound_field(form,ans).value()))
        value=form.fields[ans].get_bound_field(form,ans).value()
        if form.is_bound:        
            if form.fields[ans].get_bound_field(form,ans).errors:
                text=form.fields[ans].get_bound_field(form,ans).errors.as_text()
                error_html_text = error_html_text + str(counter) + " " + text + "<br>"            
                error_in_answers=True
            if value=="":
                text="This can't be empty"
                error_html_text = error_html_text + str(counter) + " " + text + "<br>"            
                error_in_answers=True
        
        html_field=form.fields[ans].get_bound_field(form,ans).__str__()
        output_string=re.sub(r'\$\$\$',html_field,output_string,count=1)
        #output_string=re.sub(r'\$\$\$',"<br/>",output_string,count=1)
        #print("{} {}".format(output_string,error_html))
        counter+=1
        
    if form.is_bound:    
        if error_in_answers:
            status_html='<div class="wrapper-status"><div class="status explanation-message">{}</div></div>'.format(error_html_text)   
        else:
            status_html='<div class="wrapper-status"><div class="status success-message">Excelent</div></div>'
    else:
        status_html=""
    output_string=re.sub(r'<select ',r'<select class="selectstrove" ',output_string)    
    return mark_safe("{} {}".format(output_string,status_html))    
        
        


@register.filter
def get_item(dictionary, key):
    return dictionary.get(key)