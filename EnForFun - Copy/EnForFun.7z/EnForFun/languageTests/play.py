# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 14:05:32 2019

@author: A
"""

LEVELS = (
        ('b', 'Beginner'),
        ('i', 'Intermediate'),
        ('e', 'Expert'),
)

a={}
a=dict(LEVELS)

print(a) 
print(a["b"])